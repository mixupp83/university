from module2 import say_hi as sh

print('Привет я из модуля 1')

sh()
